package com.demo.upimesh.service;

import com.demo.upimesh.crypto.HybridCryptoService;
import com.demo.upimesh.model.MeshPacket;
import com.demo.upimesh.model.PaymentInstruction;
import com.demo.upimesh.model.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * Orchestrates the full server-side pipeline for one inbound packet from a
 * bridge node:
 *
 *   1. Hash the ciphertext.
 *   2. Try to claim that hash via the idempotency cache.
 *      - If already claimed: this is a duplicate. Drop it.
 *   3. Decrypt the ciphertext with the server's private key.
 *      - If decryption fails: tampered or junk. Reject.
 *   4. Check freshness — reject if signedAt is too old (replay protection).
 *   5. Hand off to SettlementService for the actual debit/credit.
 */
@Service
public class BridgeIngestionService {

    private static final Logger log = LoggerFactory.getLogger(BridgeIngestionService.class);

    @Autowired private HybridCryptoService crypto;
    @Autowired private IdempotencyService idempotency;
    @Autowired private SettlementService settlement;

    @Value("${upi.mesh.packet-max-age-seconds:86400}")
    private long maxAgeSeconds;

    public IngestResult ingest(MeshPacket packet, String bridgeNodeId, int hopCount) {
        String packetHash = "?";
        String stage = "hash";
        try {
            packetHash = crypto.hashCiphertext(packet.getCiphertext());

            // ---- Idempotency gate ----
            stage = "claim";
            if (!idempotency.claim(packetHash)) {
                log.info("DUPLICATE packet {} from bridge {} — dropped",
                        packetHash.substring(0, 12) + "...", bridgeNodeId);
                return IngestResult.duplicate(packetHash);
            }

            // ---- Decrypt ----
            stage = "decrypt";
            PaymentInstruction instruction;
            try {
                instruction = crypto.decrypt(packet.getCiphertext());
            } catch (Exception e) {
                log.warn("Packet rejected: reason=decryption_failed, packetHash={}, bridge={}, hops={}, errorType={}, detail={}",
                        packetHash, bridgeNodeId, hopCount, e.getClass().getSimpleName(), e.getMessage());
                log.debug("Decryption failure details for packetHash={}", packetHash, e);
                return IngestResult.invalid(packetHash, "decryption_failed");
            }

            // ---- Freshness check (replay protection) ----
            stage = "freshness";
            long ageSeconds = (Instant.now().toEpochMilli() - instruction.getSignedAt()) / 1000;
            if (ageSeconds > maxAgeSeconds) {
                log.warn("Packet rejected: reason=stale_packet, packetHash={}, bridge={}, ageSeconds={}, maxAgeSeconds={}",
                        packetHash, bridgeNodeId, ageSeconds, maxAgeSeconds);
                return IngestResult.invalid(packetHash, "stale_packet");
            }
            if (ageSeconds < -300) { // small clock-skew tolerance
                log.warn("Packet rejected: reason=future_dated, packetHash={}, bridge={}, ageSeconds={}, allowedFutureSeconds=300",
                        packetHash, bridgeNodeId, ageSeconds);
                return IngestResult.invalid(packetHash, "future_dated");
            }

            // ---- Settle ----
            stage = "settlement";
            Transaction tx = settlement.settle(instruction, packetHash, bridgeNodeId, hopCount);
            // The transactional service has returned after commit. Keep the legacy API outcome.
            log.info("Payment processing committed: packetHash={}, bridge={}, hops={}, transactionId={}, ledgerStatus={}, responseOutcome=SETTLED",
                    packetHash, bridgeNodeId, hopCount, tx.getId(), tx.getStatus());
            return IngestResult.settled(packetHash, tx);

        } catch (Exception e) {
            log.error("Ingestion failed: stage={}, packetHash={}, bridge={}, hops={}, errorType={}, detail={}",
                    stage, packetHash, bridgeNodeId, hopCount, e.getClass().getSimpleName(), e.getMessage(), e);
            return IngestResult.invalid("?", "internal_error: " + e.getMessage());
        }
    }

    public record IngestResult(String outcome, String packetHash, String reason, Long transactionId) {
        public static IngestResult settled(String hash, Transaction tx) {
            return new IngestResult("SETTLED", hash, null, tx.getId());
        }
        public static IngestResult duplicate(String hash) {
            return new IngestResult("DUPLICATE_DROPPED", hash, null, null);
        }
        public static IngestResult invalid(String hash, String reason) {
            return new IngestResult("INVALID", hash, reason, null);
        }
    }
}
